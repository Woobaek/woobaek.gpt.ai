import sensor
import image
import time
import tf
import gc
from pyb import UART

# =========================
# UART SETUP
# =========================

uart = UART(3, 115200)

# =========================
# CAMERA SETUP
# =========================

sensor.reset()

sensor.set_pixformat(sensor.RGB565)

sensor.set_framesize(sensor.QQQVGA)

# 96x96 입력
sensor.set_windowing((96, 96))

# 색 안정화
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)

sensor.skip_frames(time=2000)

clock = time.clock()

# =========================
# MEMORY CLEAN
# =========================

gc.collect()

# =========================
# LOAD MODEL
# =========================

net = tf.load("fire_model.tflite", load_to_fb=True)

print("MODEL LOADED")

# =========================
# MAIN LOOP
# =========================

while(True):

    gc.collect()

    clock.tick()

    img = sensor.snapshot()

    predictions = net.classify(img)

    fire_detected = False

    for obj in predictions:

        scores = obj.output()

        fire = scores[0]
        smoke = scores[1]
        normal = scores[2]

        print("-------------------")
        print("FIRE :", fire)
        print("SMOKE:", smoke)
        print("NORMAL:", normal)

        # =====================
        # FIRE DETECTION
        # =====================

        if fire > 0.70:

            print("🔥 FIRE DETECTED")

            fire_detected = True

        # =====================
        # SMOKE DETECTION
        # =====================

        elif smoke > 0.45:

            print("☁️ SMOKE DETECTED")

        else:

            print("✅ NORMAL")

    # =====================
    # SEND SIGNAL TO ARDUINO
    # =====================

    if fire_detected:

        uart.write("1\n")

    else:

        uart.write("0\n")

    print("FPS:", clock.fps())
